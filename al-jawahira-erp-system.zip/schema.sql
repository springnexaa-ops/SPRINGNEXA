-- Initialize Cloudflare D1 Database Tables
DROP TABLE IF EXISTS certificates;
CREATE TABLE certificates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    issuer TEXT NOT NULL,
    issue_date TEXT NOT NULL,
    file_data TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

DROP TABLE IF EXISTS announcements;
CREATE TABLE announcements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    message TEXT NOT NULL,
    is_active INTEGER DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default announcement
INSERT INTO announcements (message, is_active) VALUES ('Welcome to Springnexa. DPIIT Recognized Healthtech delivering rural diagnostic equity.', 1);
