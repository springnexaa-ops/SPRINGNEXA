export async function onRequestGet({ env }) {
  try {
    const { results } = await env.DB.prepare("SELECT id, title, issuer, issue_date, file_data FROM certificates ORDER BY created_at DESC").all();
    return Response.json(results);
  } catch (e) {
    return Response.json({ error: e.message }, { status: 500 });
  }
}

export async function onRequestPost({ request, env }) {
  try {
    const data = await request.json();
    const result = await env.DB.prepare(
      "INSERT INTO certificates (title, issuer, issue_date, file_data) VALUES (?, ?, ?, ?)"
    ).bind(data.title, data.issuer, data.date, data.fileData).run();
    return Response.json({ success: true, id: result.meta.last_row_id });
  } catch (e) {
    return Response.json({ error: e.message }, { status: 500 });
  }
}

export async function onRequestDelete({ request, env }) {
  try {
    const url = new URL(request.url);
    const id = url.searchParams.get('id');
    await env.DB.prepare("DELETE FROM certificates WHERE id = ?").bind(id).run();
    return Response.json({ success: true });
  } catch (e) {
    return Response.json({ error: e.message }, { status: 500 });
  }
}
