export async function onRequestGet({ env }) {
  try {
    const { results } = await env.DB.prepare("SELECT message FROM announcements WHERE is_active = 1 ORDER BY created_at DESC LIMIT 1").all();
    return Response.json(results[0] || { message: "" });
  } catch (e) {
    return Response.json({ error: e.message }, { status: 500 });
  }
}

export async function onRequestPost({ request, env }) {
  try {
    const data = await request.json();
    await env.DB.prepare("UPDATE announcements SET is_active = 0").run();
    if (data.message) {
        await env.DB.prepare("INSERT INTO announcements (message, is_active) VALUES (?, 1)").bind(data.message).run();
    }
    return Response.json({ success: true });
  } catch (e) {
    return Response.json({ error: e.message }, { status: 500 });
  }
}
